import { useFocusEffect } from "@react-navigation/native";
import Constants from "expo-constants";
import React, { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { RFValue } from "react-native-responsive-fontsize";

import {
    Alert,
    BackHandler,
    Image,
    Linking,
    StatusBar,
    Text,
    View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Images } from "../../assets/images";
import ButtonComponent from "../../components/buttonComponent.tsx";
import { Colors } from "../../utils/colors";
import { styles } from "./style";



// export default OnBoarding;

const OnBoarding = ({ navigation }) => {
    const { t } = useTranslation();
    const [appVersion, setAppVersion] = useState("");

    const handleBackPress = useCallback(() => {
        Alert.alert("Hold on!", t("Are you sure you want to exit?"), [
            {
                text: "Cancel",
                onPress: () => null,
                style: "cancel",
            },
            { text: "YES", onPress: () => BackHandler.exitApp() },
        ]);
        return true;
    }, []);

    useFocusEffect(
        useCallback(() => {
            const backHandler = BackHandler.addEventListener(
                'hardwareBackPress',
                handleBackPress
            );

            return () => backHandler.remove(); // Correct way to remove listener
        }, [])
    );

    useEffect(() => {
        retrieveAppVersion();
    }, []);

const retrieveAppVersion = async () => {
  try {
    const version =
      Constants.expoConfig?.version ||
      Constants.manifest?.version || 
      "Unknown";
    setAppVersion(version);
  } catch (error) {
    console.error("Error retrieving app version:", error);
  }
};

    const openURL = () => {
        Linking.openURL("https://www.erpportaal.nl/").catch((err) =>
            console.error("An error occurred", err)
        );
    };

    return (
        <SafeAreaView style={styles.safe}>
            <StatusBar backgroundColor={Colors.white} barStyle={"dark-content"} />
            <KeyboardAwareScrollView
                bounces={false}
                enableOnAndroid
                extraScrollHeight={70}
                keyboardShouldPersistTaps="handled"
                style={styles.subContainer}
            >
                <View style={{ justifyContent: "center", flex: 1 }}>
                    <Image source={Images.roundlogo} style={styles.logo} />

                    <View style={styles.container}>
                        <Text style={styles.wellcome}>{t("Welkom bij ERP TMS Driver")}</Text>
                        <Text style={styles.dis}>
                            {t("Smart Solutions for Modern Businesses")}
                        </Text>
                        <Text style={styles.dis}>
                            {t("Release V")}
                            {appVersion}
                        </Text>
                        <Text
                            onPress={openURL}
                            style={[styles.dis, { marginTop: 5, color: Colors.primary }]}
                        >
                            www.erpportaal.nl
                        </Text>
                    </View>
                </View>
            </KeyboardAwareScrollView>
            <View
                style={{
                    marginHorizontal:'auto',
                    width: "90%",
                    marginBottom:50,
                    gap:10
                }}
            >
                <ButtonComponent
                    onPress={() => navigation.navigate("Register", { typee: "Register" })}
                    marginTop={RFValue(50)}
                    title={t("Registrere")+"n"}
                />
                <ButtonComponent
                    onPress={() => navigation.navigate("Register", { typee: "Login" })}
                    marginTop={RFValue(10)}
                    title={t("Inloggen")}
                    // backgroundColor={Colors.white}
                    // borderWidth={1.5}
                    // borderColor={Colors.litegray}
                    // color={Colors.black}
                />
            </View>
        </SafeAreaView>
    );
};

export default OnBoarding;

