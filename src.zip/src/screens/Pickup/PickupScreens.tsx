import { View, Text } from 'react-native'
import React from 'react'
import { styles } from './style'

export default function PickupScreens() {
  return (
    <View style={styles.container}>
      <Text>PickupScreens</Text>
    </View>
  )
}