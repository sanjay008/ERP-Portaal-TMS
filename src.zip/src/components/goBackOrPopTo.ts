export function goBackOrPopTo(
  navigation: any,
  targetScreen: string,
  params?: any
) {
  const state = navigation.getState();
  const routes = state.routes;

  const index = routes.findIndex((r: any) => r.name === targetScreen);

  if (index !== -1) {
    const popCount = routes.length - 1 - index;

    if (popCount > 0) {
      navigation.pop(popCount);
    }

    if (params) {
      navigation.navigate(targetScreen, {
        ...params,
        _fromBack: true,
      });
    }

  } else {
    navigation.goBack();

    if (params) {
      const prev = routes[routes.length - 2];
      if (prev) {
        navigation.navigate(prev.name, {
          ...params,
          _fromBack: true,
        });
      }
    }
  }
}
